# DBMS Lab End Sem
Open Final_Presentation.pptx (8 readout slides, then technical appendix). Full numerical tables and charts are in results/. SQL uses SQLite and runs through analysis.py; raw CSVs must be placed in a directory supplied as the first argument.

## Reproduce
Python 3.10+; install dependencies with `pip install -r requirements.txt`. From this folder run `python analysis.py /path/to/csv_directory` then `python make_deck.py`. The deck uses the computed results from this supplied dataset; slide text is authored and should be updated if the dataset changes.

## Definitions and limitations
Device-level analysis, not resolved human identities. Signed USD is used for Q2 and Q3; Q1 reports gross and net separately. Concentration ranks positive-net payers only; repeat gaps use all recorded signed transaction events. First purchase is profile-reported and negative gaps are isolated; missing first purchase is not proof of lifetime nonpayment. Distinct events sharing IDs retained pending ledger reconciliation. Ad views are interactions and completed views are separately counted. Missing days are zero recorded events, not necessarily zero activity. Cohort retention uses complete milestone exposure for the entire observed install-week cohort. Channel inference is observational; HC3 intervals assume independent device records, which linked devices may violate. Churn model is not causal; thresholds are illustrative, not optimised on test data. Optional Q4b omitted.
