import pandas as pd, numpy as np, sqlite3, pathlib, sys
from scipy.stats import norm
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score,average_precision_score,confusion_matrix
import matplotlib.pyplot as plt
base=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '..'); out=pathlib.Path('results'); out.mkdir(exist_ok=True)
p,d,t,a,c=[pd.read_csv(base/(x+'.csv')) for x in ['player_profile','player_day','purchase','ad_view','currency_spend']]
log=[]
for name,x in zip(['profile','day','purchase','ad','spend'],[p,d,t,a,c]):
 log.append(f'{name}: {len(x)} rows; exact duplicates {x.duplicated().sum()}; missing {x.isna().sum().to_dict()}')
log.append(f'Profile duplicate IDs {p.device_id.duplicated().sum()}; linked devices {p.original_device_id.notna().sum()}; purchase repeated IDs {t.purchase_id.duplicated().sum()}; repeated player-days {d.duplicated(["device_id","activity_date"]).sum()}')
p=p.drop_duplicates('device_id'); d=d.drop_duplicates(); t=t.drop_duplicates(); a=a.drop_duplicates(); c=c.drop_duplicates()
# Conflicting purchase IDs retained if distinct event records; cannot establish which is valid.
for x in [d,t,a,c]:
 log.append(f'Unmatched device rows: {sum(~x.device_id.isin(p.device_id))}')
 x.drop(x.index[~x.device_id.isin(p.device_id)],inplace=True)
d['day']=pd.to_datetime(d.activity_date.astype(str),format='%Y%m%d',errors='coerce'); t['day']=pd.to_datetime(t.event_ts,errors='coerce').dt.normalize(); a['day']=pd.to_datetime(a.event_ts,errors='coerce').dt.normalize(); p['install']=pd.to_datetime(p.install_date,errors='coerce')
start=pd.Timestamp('2026-01-01'); end=pd.Timestamp('2026-04-30')
for x in [d,t,a]: x.drop(x.index[~x.day.between(start,end)],inplace=True)
d=d.groupby(['device_id','day'],as_index=False).agg(session_count=('session_count','max'),playtime_minutes=('playtime_minutes','max'),player_level=('player_level','max'))
for x in [p,d,t,a]:
 for col in x.select_dtypes(include='datetime').columns: x[col]=x[col].dt.strftime('%Y-%m-%d')
con=sqlite3.connect(':memory:')
for name,x in zip(['profile','activity','purchase','ads'],[p,d,t,a]): x.to_sql(name,con,index=False)
queries=pathlib.Path('queries.sql').read_text().split('-- RESULT ')
for q in queries[1:]:
 name,sql=q.split('\n',1); pd.read_sql_query(sql,con).to_csv(out/(name.strip()+'.csv'),index=False)
# Tier decomposition
act=d.merge(p[['device_id','country_tier']],on='device_id'); rev=t.merge(p[['device_id','country_tier']],on='device_id')
rows=[]
for label,lo,hi in [('first','2026-01-01','2026-01-30'),('last','2026-04-01','2026-04-30')]:
 n=act[act.day.between(lo,hi)].groupby('country_tier').size(); r=rev[rev.day.between(lo,hi)].groupby('country_tier').usd_amount.sum(); z=pd.DataFrame({'days':n,'revenue':r}).fillna(0); z['weight']=z.days/z.days.sum(); z['arpdau']=z.revenue/z.days; z['period']=label; rows.append(z.reset_index())
z=pd.concat(rows); z.to_csv(out/'tier.csv',index=False); f,l=[z[z.period==k].set_index('country_tier') for k in ['first','last']]; mix=((l.weight-f.weight)*(l.arpdau+f.arpdau)/2).sum(); within=((l.arpdau-f.arpdau)*(l.weight+f.weight)/2).sum(); log.append(f'ARPDAU first {(f.weight*f.arpdau).sum():.6f}, last {(l.weight*l.arpdau).sum():.6f}; mix {mix:.6f}, within {within:.6f}')
# Comparable new installs with 30 days observation
p['install']=pd.to_datetime(p.install); d['day']=pd.to_datetime(d.day); t['day']=pd.to_datetime(t.day)
co=p[p.install.between(start,end-pd.Timedelta(days=29))].copy(); co['week']=co.install.dt.to_period('W').astype(str)
for x,col,agg in [(d,'active_days','size'),(t,'revenue','sum')]:
 j=x.merge(co[['device_id','install']],on='device_id'); j=j[(j.day-j.install).dt.days.between(0,29)]; v=j.groupby('device_id').size() if agg=='size' else j.groupby('device_id').usd_amount.sum(); co[col]=co.device_id.map(v).fillna(0)
co.groupby('acquisition_channel')[['active_days','revenue']].agg(['size','mean','std']).to_csv(out/'channels.csv')
# adjusted OLS with robust SE, controls tier, platform, install week
import statsmodels.formula.api as smf
for y in ['active_days','revenue']:
 m=smf.ols(f'{y} ~ C(acquisition_channel, Treatment(reference="organic")) + C(country_tier) + C(platform) + C(week)',data=co).fit(cov_type='HC3'); tab=pd.concat([m.params,m.conf_int(),m.pvalues],axis=1); tab.columns=['estimate','low','high','p']; tab.to_csv(out/f'adjusted_{y}.csv')
# snapshots: active in prior 7 days; no activity next 14 days; nonoverlapping label windows
frames=[]
for date in ['2026-02-01','2026-02-15','2026-03-01','2026-03-15','2026-03-29','2026-04-15']:
 s=pd.Timestamp(date); hist=d[d.day.between(s-pd.Timedelta(days=13),s)]; eligible=hist[hist.day>=s-pd.Timedelta(days=6)].device_id.unique(); feat=hist.groupby('device_id').agg(days=('day','size'),sessions=('session_count','sum'),minutes=('playtime_minutes','sum'),level=('player_level','max'),last=('day','max')).loc[eligible]; feat['recency']=(s-feat.pop('last')).dt.days; feat['revenue']=t[t.day.between(s-pd.Timedelta(days=13),s)].groupby('device_id').usd_amount.sum(); feat=feat.fillna(0); feat['churn']=(~feat.index.isin(d[d.day.between(s+pd.Timedelta(days=1),s+pd.Timedelta(days=14))].device_id)).astype(int); feat['snapshot']=date; frames.append(feat.reset_index())
features=['days','sessions','minutes','level','recency','revenue']; train=pd.concat(frames[:4]); val=frames[4]; test=frames[5]; model=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000)); model.fit(train[features],train.churn); scores=model.predict_proba(test[features])[:,1]; log.append(f'Churn train {len(train)}, validation {len(val)}, test {len(test)}, prevalence {test.churn.mean():.4f}, ROC AUC {roc_auc_score(test.churn,scores):.4f}, AP {average_precision_score(test.churn,scores):.4f}')
metrics=[]
for threshold in [.2,.3,.5,.7]:
 tn,fp,fn,tp=confusion_matrix(test.churn,scores>=threshold,labels=[0,1]).ravel(); metrics.append([threshold,tn,fp,fn,tp,tp/max(1,tp+fp),tp/max(1,tp+fn)])
pd.DataFrame(metrics,columns=['threshold','TN','FP','FN','TP','precision','recall']).to_csv(out/'churn.csv',index=False)
for name,grp in test.assign(score=scores).groupby(pd.cut(test.days,[0,2,5,14])):
 log.append(f'Churn segment {name}: n={len(grp)}, observed={grp.churn.mean():.3f}, predicted={grp.score.mean():.3f}')
for name,table in [('tier',z.pivot(index='country_tier',columns='period',values='arpdau')),('mix',z.pivot(index='country_tier',columns='period',values='weight')),('ads',pd.read_csv(out/'ad_daily.csv').set_index('day')),('installs',p[p.install.between(start,end)].groupby(p.install.dt.to_period('W')).size())]:
 ax=table.plot(kind='bar' if name in ['tier','mix'] else 'line',figsize=(9,4),title=name); ax.set_ylabel({'tier':'USD per active player-day','mix':'Share of active player-days','ads':'Interactions','installs':'Installs'}[name]); plt.tight_layout(); plt.savefig(out/(name+'.png'),dpi=150); plt.close()
(out/'audit.txt').write_text('\n'.join(log)); print('\n'.join(log))
